import { WaterHeader } from "@/components/WaterHeader";
import { WaterHero } from "@/components/WaterHero";
import { WaterServices } from "@/components/WaterServices";
import { WaterUpdates } from "@/components/WaterUpdates";
import { WaterFooter } from "@/components/WaterFooter";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <WaterHeader />
      <main>
        <WaterHero />
        <WaterServices />
        <WaterUpdates />
      </main>
      <WaterFooter />
    </div>
  );
};

export default Index;
