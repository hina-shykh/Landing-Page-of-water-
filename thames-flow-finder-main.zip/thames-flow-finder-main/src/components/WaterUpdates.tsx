import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Clock, Info } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const WaterUpdates = () => {
  const { toast } = useToast();

  const handleUpdateClick = (update: string) => {
    toast({
      title: "Update Details",
      description: `Loading information for: ${update}`,
    });
  };

  const updates = [
    {
      type: "Maintenance",
      title: "Planned Water Supply Interruption",
      location: "South East London - SE1, SE5, SE15",
      date: "Sunday, 8th December 2024",
      time: "3:00 AM - 6:00 AM",
      description: "Essential pipe maintenance to improve water quality and pressure",
      status: "upcoming",
      impact: "Low pressure or temporary supply interruption"
    },
    {
      type: "Emergency",
      title: "Water Main Repair Completed",
      location: "Richmond upon Thames - TW9, TW10",
      date: "Today",
      time: "Completed at 2:30 PM",
      description: "Emergency repair of burst water main on Richmond Road",
      status: "resolved",
      impact: "Water supply fully restored"
    },
    {
      type: "Notice",
      title: "Temporary Traffic Management",
      location: "Central London - WC1, WC2",
      date: "Monday, 9th December 2024",
      time: "9:00 AM - 4:00 PM",
      description: "Installation of new smart water meters",
      status: "scheduled",
      impact: "Minor traffic delays expected"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "upcoming": return "bg-amber-500";
      case "resolved": return "bg-green-500";
      case "scheduled": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Emergency": return "destructive";
      case "Maintenance": return "default";
      case "Notice": return "secondary";
      default: return "default";
    }
  };

  return (
    <section className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Service Updates & Notices
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Stay informed about planned works, emergency repairs, and service updates in your area
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {updates.map((update, index) => (
            <Card key={index} className="group hover:shadow-water transition-all duration-300 cursor-pointer">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between mb-2">
                  <Badge variant={getTypeColor(update.type) as any} className="mb-2">
                    {update.type}
                  </Badge>
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(update.status)}`}></div>
                </div>
                <CardTitle className="text-lg line-clamp-2 group-hover:text-primary transition-colors">
                  {update.title}
                </CardTitle>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-4 h-4 text-primary" />
                  <span className="line-clamp-1">{update.location}</span>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4 text-primary" />
                  <span>{update.date}</span>
                </div>
                
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4 text-primary" />
                  <span>{update.time}</span>
                </div>
                
                <CardDescription className="text-sm line-clamp-2">
                  {update.description}
                </CardDescription>
                
                <div className="border-t pt-4">
                  <div className="flex items-start gap-2 text-sm">
                    <Info className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                    <span className="text-muted-foreground line-clamp-2">{update.impact}</span>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-all"
                  onClick={() => handleUpdateClick(update.title)}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            variant="water" 
            size="lg"
            onClick={() => handleUpdateClick("All Updates")}
          >
            View All Updates
          </Button>
        </div>

        {/* Emergency Notice */}
        <div className="mt-16 bg-destructive/10 border border-destructive/20 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-destructive rounded-full flex items-center justify-center flex-shrink-0">
              <Info className="w-6 h-6 text-destructive-foreground" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-destructive mb-2">
                Drought Update - Water Saving Measures in Effect
              </h3>
              <p className="text-muted-foreground mb-4">
                We're asking all customers to help us save water during this dry period. 
                Simple steps like taking shorter showers and fixing leaks can make a big difference.
              </p>
              <Button 
                variant="destructive" 
                size="sm"
                onClick={() => handleUpdateClick("Drought Information")}
              >
                Learn More About Water Saving
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};