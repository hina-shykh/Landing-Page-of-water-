import { Button } from "@/components/ui/button";
import { ArrowRight, Shield, Users, Droplets } from "lucide-react";
import heroImage from "@/assets/hero-water.jpg";

export const WaterHero = () => {
  return (
    <section className="relative min-h-[600px] flex items-center">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-20">
        <div className="max-w-2xl">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Welcome to
            <span className="block text-transparent bg-gradient-to-r from-blue-300 to-cyan-300 bg-clip-text">
              Thames Water
            </span>
          </h1>
          
          <p className="text-xl text-white/90 mb-8 leading-relaxed">
            We take care of water for 16 million people, enabling our customers, 
            communities, and environment to thrive.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Button 
              size="lg" 
              variant="water"
              className="text-lg px-8 py-4 h-auto"
            >
              Manage Your Account
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              className="text-lg px-8 py-4 h-auto bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white hover:text-primary"
            >
              Pay Your Bill
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="flex items-center gap-3 text-white">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Users className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-bold">16M</div>
                <div className="text-sm text-white/80">People Served</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3 text-white">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Droplets className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-bold">99.95%</div>
                <div className="text-sm text-white/80">Quality Standard</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3 text-white">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                <Shield className="w-6 h-6" />
              </div>
              <div>
                <div className="text-2xl font-bold">24/7</div>
                <div className="text-sm text-white/80">Emergency Support</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};