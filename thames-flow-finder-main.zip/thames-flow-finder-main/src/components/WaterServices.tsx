import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CreditCard, Home, AlertTriangle, Wrench, FileText, Phone } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const WaterServices = () => {
  const { toast } = useToast();

  const handleServiceClick = (service: string) => {
    toast({
      title: `${service} Service`,
      description: "Redirecting to service portal...",
    });
  };

  const services = [
    {
      icon: CreditCard,
      title: "Pay Your Bill",
      description: "Quick and secure online bill payments",
      color: "bg-gradient-water",
      action: () => handleServiceClick("Bill Payment")
    },
    {
      icon: Home,
      title: "Manage Your Account",
      description: "View usage, update details, and manage services",
      color: "bg-gradient-wave",
      action: () => handleServiceClick("Account Management")
    },
    {
      icon: AlertTriangle,
      title: "Report a Problem",
      description: "Water leaks, supply issues, or emergencies",
      color: "bg-destructive",
      action: () => handleServiceClick("Problem Report")
    },
    {
      icon: Wrench,
      title: "Moving Home",
      description: "Transfer your account to a new address",
      color: "bg-accent",
      action: () => handleServiceClick("Moving Service")
    },
    {
      icon: FileText,
      title: "Property Searches",
      description: "Drainage and water information for properties",
      color: "bg-secondary",
      action: () => handleServiceClick("Property Search")
    },
    {
      icon: Phone,
      title: "Emergency Support",
      description: "24/7 support for urgent water issues",
      color: "bg-primary",
      action: () => handleServiceClick("Emergency Support")
    }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-foreground mb-4">
            How Can We Help You Today?
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Quick access to all your water services and support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <Card 
                key={index} 
                className="group hover:shadow-water transition-all duration-300 hover:-translate-y-2 cursor-pointer border-0 shadow-md"
                onClick={service.action}
              >
                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 ${service.color} rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-xl group-hover:text-primary transition-colors">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <CardDescription className="text-base mb-6">
                    {service.description}
                  </CardDescription>
                  <Button 
                    variant="outline" 
                    className="w-full group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all duration-300"
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Quick Actions Section */}
        <div className="mt-16 bg-gradient-water rounded-2xl p-8 text-white">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-4">Need Immediate Help?</h3>
              <p className="text-lg opacity-90 mb-6">
                For water emergencies or urgent issues, contact our 24/7 support team
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  variant="outline"
                  size="lg"
                  className="bg-white/20 border-white/30 text-white hover:bg-white hover:text-primary backdrop-blur-sm"
                  onClick={() => handleServiceClick("Emergency Call")}
                >
                  <Phone className="w-5 h-5 mr-2" />
                  Call Emergency Line
                </Button>
                <Button 
                  variant="outline"
                  size="lg"
                  className="bg-white/20 border-white/30 text-white hover:bg-white hover:text-primary backdrop-blur-sm"
                  onClick={() => handleServiceClick("Live Chat")}
                >
                  Start Live Chat
                </Button>
              </div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold mb-2">0345 9200 800</div>
              <div className="text-lg opacity-90">24/7 Emergency Hotline</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};