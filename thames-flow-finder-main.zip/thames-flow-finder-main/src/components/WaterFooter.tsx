import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Droplets, Facebook, Twitter, Instagram, Linkedin, Phone, Mail, MapPin } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export const WaterFooter = () => {
  const { toast } = useToast();
  const [email, setEmail] = useState("");

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast({
        title: "Newsletter Subscription",
        description: "Thank you for subscribing to our updates!",
      });
      setEmail("");
    }
  };

  const handleSocialClick = (platform: string) => {
    toast({
      title: `${platform}`,
      description: `Opening ${platform} page...`,
    });
  };

  return (
    <footer className="bg-primary text-primary-foreground">
      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <span className="text-xl font-bold">Thames Water</span>
            </div>
            <p className="text-primary-foreground/80 text-sm leading-relaxed">
              Serving 16 million people across London and the Thames Valley with 
              clean, safe water and reliable wastewater services.
            </p>
            <div className="flex space-x-3">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-10 h-10 p-0 hover:bg-white/20"
                onClick={() => handleSocialClick("Facebook")}
              >
                <Facebook className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-10 h-10 p-0 hover:bg-white/20"
                onClick={() => handleSocialClick("Twitter")}
              >
                <Twitter className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-10 h-10 p-0 hover:bg-white/20"
                onClick={() => handleSocialClick("Instagram")}
              >
                <Instagram className="w-5 h-5" />
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-10 h-10 p-0 hover:bg-white/20"
                onClick={() => handleSocialClick("LinkedIn")}
              >
                <Linkedin className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Pay Your Bill</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Manage Account</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Report a Problem</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Moving Home</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Water Quality</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Help & Support</a></li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Services</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Property Searches</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Developer Services</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Business Services</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Water Efficiency</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Smart Meters</a></li>
              <li><a href="#" className="text-primary-foreground/80 hover:text-white transition-colors">Vulnerable Customers</a></li>
            </ul>
          </div>

          {/* Newsletter & Contact */}
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4">Stay Updated</h3>
              <form onSubmit={handleNewsletterSubmit} className="space-y-3">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/60"
                />
                <Button 
                  type="submit" 
                  variant="outline"
                  className="w-full bg-white/20 border-white/30 text-white hover:bg-white hover:text-primary"
                >
                  Subscribe
                </Button>
              </form>
            </div>

            <div className="space-y-3">
              <h4 className="font-semibold">Emergency Contact</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  <span>0345 9200 800</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  <span>help@thameswater.co.uk</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/20">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="flex flex-wrap items-center gap-6 text-sm text-primary-foreground/80">
              <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
              <a href="#" className="hover:text-white transition-colors">Accessibility</a>
            </div>
            <div className="text-sm text-primary-foreground/80">
              © 2024 Thames Water. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};