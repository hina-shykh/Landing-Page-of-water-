import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Menu, X, Droplets } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const WaterHeader = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      toast({
        title: "Searching...",
        description: `Looking for "${searchQuery}"`,
      });
    }
  };

  const handleLogin = () => {
    toast({
      title: "Login",
      description: "Redirecting to account portal...",
    });
  };

  const handleRegister = () => {
    toast({
      title: "Register",
      description: "Setting up your account...",
    });
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      {/* Service Alert Bar */}
      <div className="bg-destructive text-destructive-foreground px-4 py-2">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">⚠️ Service Update:</span>
            <span className="text-sm">Planned maintenance in SE London - Sunday 3am-6am</span>
          </div>
          <Button variant="ghost" size="sm" className="text-destructive-foreground hover:bg-destructive-foreground/10">
            View Details
          </Button>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-water rounded-full flex items-center justify-center">
              <Droplets className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-primary">Thames Water</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-foreground hover:text-primary transition-colors">Account & Billing</a>
            <a href="#" className="text-foreground hover:text-primary transition-colors">Help & Advice</a>
            <a href="#" className="text-foreground hover:text-primary transition-colors">About Us</a>
          </nav>

          {/* Search and Actions */}
          <div className="hidden md:flex items-center gap-4">
            <form onSubmit={handleSearch} className="relative">
              <Input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-64 pr-10"
              />
              <Button
                type="submit"
                size="sm"
                variant="ghost"
                className="absolute right-1 top-1/2 -translate-y-1/2 p-1 h-auto"
              >
                <Search className="w-4 h-4" />
              </Button>
            </form>
            <Button variant="outline" onClick={handleRegister}>Register</Button>
            <Button variant="water" onClick={handleLogin}>Login</Button>
          </div>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="sm"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </Button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden border-t py-4">
            <nav className="flex flex-col space-y-4">
              <form onSubmit={handleSearch} className="relative mb-4">
                <Input
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pr-10"
                />
                <Button
                  type="submit"
                  size="sm"
                  variant="ghost"
                  className="absolute right-1 top-1/2 -translate-y-1/2 p-1 h-auto"
                >
                  <Search className="w-4 h-4" />
                </Button>
              </form>
              <a href="#" className="text-foreground hover:text-primary transition-colors py-2">Account & Billing</a>
              <a href="#" className="text-foreground hover:text-primary transition-colors py-2">Help & Advice</a>
              <a href="#" className="text-foreground hover:text-primary transition-colors py-2">About Us</a>
              <div className="flex gap-2 pt-4">
                <Button variant="outline" onClick={handleRegister} className="flex-1">Register</Button>
                <Button variant="water" onClick={handleLogin} className="flex-1">Login</Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};